# services/__init__.py
from .data_service import DataService

__all__ = ['DataService']