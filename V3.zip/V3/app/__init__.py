# app/__init__.py
from .main_v3 import app

__all__ = ['app']